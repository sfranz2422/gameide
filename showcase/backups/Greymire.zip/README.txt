The Lantern of Greymire

A GameIDE project. To open it, go to GameIDE's front page and use Import.
Pictures made with Google Gemini. Type: IM Fell by Igino Marini (SIL Open Font License).
