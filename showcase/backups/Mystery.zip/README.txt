Mystery Meat from Outer Space

A GameIDE project. To open it, go to GameIDE's front page and use Import.
project.json holds the objects, events, rooms and scripts; assets/ holds the pictures, sounds and fonts.
